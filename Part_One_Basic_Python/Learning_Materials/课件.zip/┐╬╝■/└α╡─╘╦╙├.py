# 第一周
# 数算B机考试内容主要是在栈、树、图、排序，尤其是经典算法例如：shunting yard, dijkstra；
# 类的写法
"""
class Treenode
    def __init__(self):
    ...
"""


# FRACTION 的写法

def gcd(m, n):
    while m % n != 0:
        oldm = m
        oldn = n

        m = oldn
        n = oldm % oldn
    return n


class Fraction:
    def __init__(self, son, mum):
        self.son = son
        self.mum = mum

    def __str__(self):
        return str(self.son) + "/" + str(self.mum)

    def show(self):
        print(self.son, "/", self.mum)

    def __add__(self, otherfraction):
        new_son = self.mum * otherfraction.son + self.son * otherfraction.mum
        new_mum = self.mum * otherfraction.mum
        common = gcd(new_mum, new_son)
        return Fraction(new_son // common, new_mum // common)


a, b, c, d = map(int, input().split())  # map的使用要牢记 多个数字在同一行输入
x = Fraction(a, b)
y = Fraction(c, d)
print(x + y)

