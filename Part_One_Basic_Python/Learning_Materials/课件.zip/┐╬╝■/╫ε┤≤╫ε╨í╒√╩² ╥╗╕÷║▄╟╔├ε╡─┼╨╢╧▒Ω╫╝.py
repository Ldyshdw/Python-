# 最大最小整数 思路排一个最大的 最小的为反向
# 如何排出最大的 看数
def max_min_integer(n, nums):
    nums = sorted(nums, key=lambda x: (str(x) * 3, x), reverse=True)
    max_num = int(''.join(map(str, nums)))
    nums = sorted(nums, key=lambda x: (str(x) * 3, x))
    min_num = int(''.join(map(str, nums)))
    return max_num, min_num


if __name__ == "__main__":
    n = int(input())
    nums = list(map(int, input().split()))
    max_num, min_num = max_min_integer(n, nums)
    print(max_num, min_num)
