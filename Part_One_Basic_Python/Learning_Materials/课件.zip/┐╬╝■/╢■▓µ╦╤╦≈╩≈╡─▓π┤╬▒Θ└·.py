# 二叉搜索树的层次遍历
class TreeNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


def insert(node, value): 
    if node is None:
        return TreeNode(value)
    if value < node.value:
        node.left = insert(node.left, value)
    elif value > node.value:
        node.right = insert(node.right, value)
    return node


def level_order_traversal(root):
    queue = [root]
    traversal = []
    while queue:
        node = queue.pop(0)
        traversal.append(node.value)
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)
    return traversal


numbers = list(map(int, input().strip().split()))
numbers = list(dict.fromkeys(numbers))
root = None
for number in numbers:
    root = insert(root, number)
    traversal = level_order_traversal(root)

print(' '.join(map(str, traversal)))
