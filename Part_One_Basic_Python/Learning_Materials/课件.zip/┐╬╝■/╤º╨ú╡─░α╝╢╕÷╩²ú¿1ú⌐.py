# 学校的班级个数
def find(x):
    if parent[x] != x:  # 如果不是根结点，继续循环
        parent[x] = find(parent[x])
    return parent[x]


def union(x, y):
    parent[find(x)] = find(y)


n, m = map(int, input().split())
parent = list(range(n + 1))  # parent[i] == i，则说明元素i是该集合的根结点

for _ in range(m):
    a, b = map(int, input().split())
    union(a, b)

classes = set(find(x) for x in range(1, n + 1))
print(len(classes))
