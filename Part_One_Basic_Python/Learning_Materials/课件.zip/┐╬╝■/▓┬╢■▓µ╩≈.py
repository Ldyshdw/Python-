# 猜二叉树
from collections import deque


class TreeNode:
    def __init__(self, x):
        self.value = x
        self.left = None
        self.right = None


def build_tree(inorder, postorder):
    if not inorder or not postorder:
        return None
    root_value = postorder.pop()
    root_index = inorder.index(root_value)
    root = TreeNode(root_value)

    root.right = build_tree(inorder[root_index + 1:], postorder)
    root.left = build_tree(inorder[:root_index], postorder)

    return root


def bsf(root):
    if root is None:
        return []
    result = []
    queue = deque([root])
    while queue:
        node = queue.popleft()
        result.append(node.value)
        if node.left:
            queue.append(node.left)
        if node.right:
            queue.append(node.right)
    return result


n = int(input())
for _ in range(n):
    inorder = list(input().strip())
    postorder = list(input().strip())
    root = build_tree(inorder, postorder)
    print(''.join(bsf(root)))
