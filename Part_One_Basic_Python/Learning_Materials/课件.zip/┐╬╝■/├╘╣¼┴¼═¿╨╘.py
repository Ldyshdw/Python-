# 迷宫连通性——一个班级吗？
def find(x):
    if parent[x] != x:
        parent[x] = find(parent[x])
    return parent[x]


def union(a, b):
    parent[find(a)] = find(b)


n, m = map(int, input().strip().split())
parent = list(range(n + 1))
for _ in range(m):
    a, b = map(int, input().split())
    union(a,b)

sets = set(find(x) for x in range(1,n+1))
if len(sets) == 1:
    print('Yes')
else:
    print('No')
