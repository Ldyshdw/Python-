# merge sort 简单dfs思路 可以用栈尝试，不用指针
def merge_sort(arr):
    if len(arr) > 1:
        mid = len(arr) // 2  # 单斜杠返回浮点数 双斜杠返回整数
        L = arr[:mid]
        R = arr[mid:]

        merge_sort(L)
        merge_sort(R)
        i = j = k = 0
        while i < len(L) and j < len(R):  # 每一次回溯后，遇见的L和R都是排好序的，只需要将他们按照大小顺序合并即可
            if L[i] <= R[j]:  # 比较直到其中一边的指针结束
                arr[k] = L[i]
                i += 1
            else:
                arr[k] = R[j]
                j += 1
            k += 1

        while i < len(L):  # 将剩下所有的全部加进来
            arr[k] = L[i]
            i += 1
            k += 1

        while j < len(R):
            arr[k] = R[j]
            j += 1
            k += 1


arr = [int(x) for x in input().split()]
print(merge_sort(arr))
