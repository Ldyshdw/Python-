# 校门外的树
m, n = map(int, input().split())
Road = [True] * (m+1)
for i in range(n):
    start, stop = map(int, input().split())
    for _ in range(start, stop + 1):
        Road[_] = False
sum = 0
for i in Road:
    if i:
        sum += 1

print(sum)
