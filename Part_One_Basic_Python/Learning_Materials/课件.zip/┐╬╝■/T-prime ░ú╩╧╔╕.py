# T-prime
# T-prime 是指质数的平方
# 利用埃氏筛筛选素数
N = 1000
primes = []
cnt = 0


def get_primes(n):
    global cnt, primes
    st = [False for i in range(N)]  # 是否被筛过
    for i in range(2, n + 1):
        if (st[i] == 0):  # 如果没被筛过 是素数
            primes.append(i)  # 放到素数列表中
            cnt += 1
        for j in range(N):
            if (primes[j] > n // i):
                break  # 枚举已经筛过的素数
            st[primes[j] * i] = 1  # 将他们标为已经筛过了
            if (i % primes[j] == 0):
                break
