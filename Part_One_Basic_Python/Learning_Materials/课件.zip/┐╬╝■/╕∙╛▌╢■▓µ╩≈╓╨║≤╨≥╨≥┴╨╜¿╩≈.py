# 根据二叉树中后序建树
class TreeNode:
    def __init__(self, x):
        self.value = x
        self.left = None
        self.right = None


def build_tree(inorder, postorder):
    if not inorder or not postorder:
        return None
    root_value = postorder.pop()
    root = TreeNode(root_value)
    root_index = inorder.index(root_value)
    root.right = build_tree(inorder[root_index + 1:], postorder)
    root.left = build_tree(inorder[:root_index], postorder)
    return root


def preorder(root):
    result = []
    if root:
        result.append(root.value)
        result.extend(preorder(root.left))
        result.extend(preorder(root.right))
    return result


inorder = list(input())
postorder = list(input())
preorder = preorder(build_tree(inorder,postorder))
print(''.join(preorder))
