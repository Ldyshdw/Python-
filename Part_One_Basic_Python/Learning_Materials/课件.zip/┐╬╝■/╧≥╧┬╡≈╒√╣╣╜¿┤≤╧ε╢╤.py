# 向下调整构建大项堆
import heapq

n = int(input().strip())
heap = list(map(int, input().strip().split()))
heap = [-x for x in heap]

heapq.heapify(heap)

ans = [-x for x in heap]
print(*ans)
