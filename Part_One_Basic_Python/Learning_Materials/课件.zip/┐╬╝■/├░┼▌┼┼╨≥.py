# 第二周 时间复杂度 主要是一些排序算法 和 其O的分析
# 冒泡排序
def bubblesort(arr):
    for i in range(len(arr)):
        swapped = False
        for j in range(0, len(arr) - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if (swapped == False):
            break
    return arr


if __name__ == "__main__":
    arr = [int(x) for x in input().split()]  # 这句话也是很重要的接受数据的格式
    print(" ".join(map(str, bubblesort(arr))))
