# she'll sort
def shell_sort(arr, n):
    gap = n // 2
    while gap > 0:
        j = gap
        while j < n:
            i = j - gap
            while i >= 0:
                if arr[i + gap] > arr[i]:
                    break
                else:
                    arr[i + gap], arr[i] = arr[i], arr[i + gap]
                i = i - gap  # 往前找 负数退出循环 就是一次变动导致这一系列位置都需要整理 例如找到最小的
            j += 1  # 向后找 直到找完
    gap = gap // 2


arr = [int(x) for x in input()]
print(arr, len(arr))
