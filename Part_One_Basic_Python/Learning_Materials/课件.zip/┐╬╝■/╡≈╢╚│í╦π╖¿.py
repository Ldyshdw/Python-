# 中序表达式转为后序表达式
def infix_to_postfix(expression):
    precedence = {'+': 1, '-': 1, '*': 2, '/': 2}
    stack = []
    postfix = []
    number = ''
    for char in expression:
        if char.isnumeric() or char == '.':
            number += char
        else:
            if number:
                num = float(number)
                postfix.append(int(num) if num.is_integer() else num)
                # 如果变量num是一个整数（即num.is_integer()返回True），那么就将num转换为整数并添加到postfix列表的末尾；否则，直接将num添加到postfix列表的末尾。
                number = ''
            if char in '+-*/':
                while stack and stack[-1] in '+-*/' and precedence[char] <= precedence[stack[-1]]:
                    postfix.append(stack.pop())
                stack.append(char)
            elif char == '(':
                stack.append(char)
            elif char == ')':
                while stack and stack[-1] != '(':
                    postfix.append(stack.pop())
                stack.pop()
            # 处理括号的情况
    if number:
        num = float(number)
        postfix.append(int(num) if num.is_integer() else num)
        # 把剩下的所有数字全部加上

    while stack:
        postfix.append(stack.pop())
        # 把剩下的所有符号全部加上
    return ' '.join(str(x) for x in postfix)
    # 返回postfix整合后结果
