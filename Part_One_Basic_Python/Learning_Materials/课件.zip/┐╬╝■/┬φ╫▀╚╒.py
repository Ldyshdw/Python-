# 马走日
s = int(input())
for _ in range(s):
    m, n, a, b = map(int, input().split())
    dirs = [(2, 1), (1, 2), (-2, 1), (-1, 2), (2, -1), (1, -2), (-1, -2), (-2, -1)]
    borad = [[0] * n for x in range(m)]
    cut = 0


    def move(x, y, step):
        global cut
        if step == n * m:
            cut += 1
            return
        for i in range(8):
            move_x = x + dirs[i][0]  # 表示列表中第i个元组的第一个元素
            move_y = y + dirs[i][1]
            if move_x >= 0 and move_x <= m - 1 and move_y >= 0 and move_y <= n - 1 and borad[move_x][move_y] == 0:
                borad[move_x][move_y] = 1
                move(move_x, move_y, step + 1)
                borad[move_x][move_y] = 0


    borad[a][b] = 1
    move(a, b, 1)
    print(cut)
