# 括号匹配问题 —— 有简单有难
# stack 中存储位置 方便后续将未匹配的（匹配好 思路灵活 对于栈的运用比较熟练

lines = []
while True:
    try:
        lines.append(input())
    except EOFError:
        break

ans = []
for s in lines:
    stack = []
    Mark = []
    for i in range(len(s)):
        if s[i] == "(":
            stack.append(i)
            Mark += ' '
        elif s[i] == ")":
            if len(stack) == 0:
                Mark += '?'
            else:
                Mark += ' '
                stack.pop()
        else:
            Mark += ' '

    while (len(stack)):
        Mark[stack[-1]] = '$'
        stack.pop()

    print(s)
    print(''.join(map(str, Mark)))
