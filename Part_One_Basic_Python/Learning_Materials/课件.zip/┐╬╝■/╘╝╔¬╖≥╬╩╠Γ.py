# 约瑟夫问题
while True:
    n, m = map(int, input().split())
    if (n, m) == (0, 0):
        break
    queue = [int(x) for x in range(1, n + 1)]
    while len(queue) > 1:
        for _ in range(m):
            if _ < m - 1:
                queue.append(queue.pop(0))

            else:
                queue.pop(0)
    print(queue.pop())

