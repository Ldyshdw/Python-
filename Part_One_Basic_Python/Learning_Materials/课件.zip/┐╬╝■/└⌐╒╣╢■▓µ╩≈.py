# 扩展二叉树
def build_tree(preorder):
    if not preorder or preorder[0] == '.':  # 递归终点 当我们发现叶子结点时直接结束本次搜索
        return None, preorder[1:]
    root = preorder[0]
    left, preorder = build_tree(preorder[1:])
    right, preorder = build_tree(preorder)
    return (root, left, right), preorder  # 不然就一直找递归终点


def preorder(tree):
    if tree is None:
        return ''
    root, left, right = tree
    return root + preorder(left) + preorder(right)


def inorder(tree):
    if tree is None:
        return ''
    root, left, right = tree
    return inorder(left) + root + inorder(right)  # 中序左根右 前序根左右 后序左右根


def postorder(tree):
    if tree is None:
        return ''
    root, left, right = tree
    return postorder(left) + postorder(right) + root


pre_order = list(input())
tree, _ = build_tree(pre_order)
print(preorder(tree),postorder(tree),inorder(tree))