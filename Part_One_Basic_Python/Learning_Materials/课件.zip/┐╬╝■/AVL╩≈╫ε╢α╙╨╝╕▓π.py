# AVL树最多有几层
from functools import lru_cache


@lru_cache(maxsize=None)
def min_nodes(h):
    if h == 0: return 0
    if h == 1: return 1

    return min_nodes(h - 1) + min_nodes(h - 2) + 1


def max_height(n):
    h = 0
    while min_nodes(h) <= n:
        h += 1

    return h - 1


n = int(input())
print(max_height(n))
