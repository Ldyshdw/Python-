# 字符串提炼
string = str(input())
extra_lst = []
loci = 1
for i in range(len(string)):
    extra_lst.append(string[loci - 1])
    loci *= 2
    if loci > len(string) - 1:
        break

code = []
pointer1 = 0
pointer2 = len(extra_lst) - 1
while pointer1 <= pointer2:
    if pointer1 == pointer2:
        code.append(extra_lst[pointer1])
        break
    code.append(extra_lst[pointer1])
    pointer1 += 1
    code.append(extra_lst[pointer2])
    pointer2 -= 1

print(''.join(code))  # 一个重要的输出手段
