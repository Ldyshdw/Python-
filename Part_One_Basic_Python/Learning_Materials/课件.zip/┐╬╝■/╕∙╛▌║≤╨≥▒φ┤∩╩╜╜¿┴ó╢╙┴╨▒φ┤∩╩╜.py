# 根据后序表达式建立队列表达式
class TreeNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


def build_tree(postfix):
    stack = []
    for char in postfix:
        node = TreeNode(char)
        if char.isupper():
            node.right = stack.pop()  # 后序表达式特性左右根
            node.left = stack.pop()
        stack.append(node)
    return stack[0]


def level_order_traversal(root):  # 右左根的方式   但是我们的dfs以及循环都很难去找最后一个 所以先反着来 根左右 就是先左后右
    queue = [root]
    traversal = []
    while queue:
        node = queue.pop(0)
        traversal.append(node.value)
        if node.left:
            queue.append(node.left)

        if node.right:
            queue.append(node.right)
    return traversal


n = int(input())
for _ in range(n):
    postfix = list(input())
    root = build_tree(postfix)
    expression = level_order_traversal(root)[::-1]  # 取反
    print(''.join(expression))
