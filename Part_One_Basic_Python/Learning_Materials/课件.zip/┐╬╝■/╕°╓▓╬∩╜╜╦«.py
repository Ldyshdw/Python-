# 给植物浇水
n, a, b = map(int, input().split())
plant = [int(x) for x in input().split()]
Bob = len(plant) - 1
Bob_water = b
cnt = 0
Alice = 0
Alice_water = a
while Alice <= Bob:
    if Alice == Bob:
        if max(Alice_water, Bob_water) >= plant[Alice]:
            break
        else:
            cnt += 1
            break
    if Alice_water >= plant[Alice]:
        Alice_water -= plant[Alice]
    else:
        Alice_water = a
        Alice_water -= plant[Alice]
        cnt += 1
    Alice += 1

    if Bob_water >= plant[Bob]:
        Bob_water -= plant[Bob]
    else:
        Bob_water = b
        Bob_water -= plant[Bob]
        cnt += 1
    Bob -= 1

print(cnt)
