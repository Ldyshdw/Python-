# 2050成绩计算
from math import sqrt

N = 10000
# 判断素数，用索引
s = [True] * N
p = 2
while p * p <= N:
    if s[p]:
        for i in range(p * 2, N, p):  # 对于特定步长所具有的格式  从2p 以p步长 开始从左至右相加
            s[i] = False
    p += 1

m, n = [int(i) for i in input().split()]

for i in range(m):
    x = [int(i) for i in input().split()]
    sum = 0
    for num in x:
        root = int(sqrt(num))
        if num > 3 and s[root] and num == root * root:
            sum += num  # 做一个检验 看看到底是不是质数
    sum /= len(x)
    if sum == 0:
        print(0)
    else:
        print('%.2f' % sum)
