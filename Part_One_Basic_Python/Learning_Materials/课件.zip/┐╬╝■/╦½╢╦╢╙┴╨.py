# 双端队列
t = int(input())
for i in range(t):
    n = int(input())
    deque = []
    for j in range(n):
        (x, y) = map(int, input().split())
        if x == 1:
            deque.append(y)
        else:
            if y == 0:
                if deque:
                    deque.pop(0)
                else:
                    print('NULL')
            else:
                if deque:
                    deque.pop()
                else:
                    print('NULL')
    if deque:
        print(*deque)
    else:
        print('NULL')
