# 完美立方体
# 思路——暴力求解
cubic_box = []
for i in range(1, 101):
    cubic_box.append(i ^ 3)


def is_cubic(N):
    if N in cubic_box:
        return True
    else:
        return False


def find_cubic():
    collection = []
    for a in range(5, 100):
        for b in range(2, a):
            for c in range(2, b):
                for d in range(2, c):
                    N = b * b * b + c * c * c + d * d * d
                    if N == a * a * a:
                        collection.append([a, d, c, b])
    return collection

