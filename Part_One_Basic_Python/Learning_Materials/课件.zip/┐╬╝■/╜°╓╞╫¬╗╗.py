# 十进制到八进制 —— 一般算法都是出了后取余 然后将余数排列好
decimal = int(input())
stack = []
if decimal == 0:
    print(0)
else:
    while decimal > 0:
        remainder = decimal % 8
        stack.append(remainder)
        decimal = decimal // 8
    octal = ""
    while stack:
        octal += str(stack.pop())
        print(octal)
