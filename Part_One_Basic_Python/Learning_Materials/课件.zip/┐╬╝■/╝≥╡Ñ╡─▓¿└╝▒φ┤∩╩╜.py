def check(t):
    for i in dic:
        if abs(len(i) - len(t)) <= 1:
            if t == i:
                return 1
            p = 0
            while p < min(len(t), len(i)) and t[p] == i[p]:
                p += 1
            if t[p + 1:] == i[p + 1:] or t[p:] == i[p + 1:] or t[p + 1:] == i[p:]:
                ans.append(i)
    return 0


dic = []
while 1:
    s = input()
    if s == '#': break
    dic.append(s)
while 1:
    t = input()
    if t == '#': break
    ans = []
    if check(t):
        print(t + 'is correct')
    else:
        ans = ' '.join(ans)
        print(f' {t}: {ans}')
