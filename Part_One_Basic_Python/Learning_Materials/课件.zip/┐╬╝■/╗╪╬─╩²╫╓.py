# 回文数字
from collections import deque


def is_palindrome(num):
    num_str = deque(str(num))
    while len(num_str) > 1:
        if num_str.pop() != num_str.popleft():
            return 'NO'
    return 'YES'


while True:
    try:
        num = int(input())
        print(is_palindrome(num))
    except EOFError:
        break
