# 数字方格
def find_max(n):
    lis = []
    for a1 in range(0, n+1):
        for a2 in range(0, n+1):
            for a3 in range(0, n+1):
                if (a1 + a2) % 2 == 0 and (a2 + a3) % 3 == 0 and (a1 + a2 + a3) % 5 == 0:
                    lis.append(a1 + a2 + a3)
    return lis


n = int(input())
lis = find_max(n)
print(max(lis))