# 剪绳子
# OJ18164
import sys

try:
    fin = open('test.in', 'r').readline
except:
    fin = sys.stdin.readline

n = int(fin())
import heapq

a = list(map(int, fin().split()))
heapq.heapify(a)
ans = 0
for i in range(n - 1):
    x = heapq.heappop(a)
    y = heapq.heappop(a)
    z = x + y
    heapq.heappush(a, z)
    ans += z
print(ans)
