# 选择排序 每次选择最小的元素放在n位置
def selection_sort(arr):
    n = len(arr)
    for i in range(n):
        pointer = i  # 指针初始化需要从 i 开始
        min = arr[i]
        for j in range(i + 1, n):
            if min > arr[j]:
                min = arr[j]
                pointer = j
        arr[i], arr[pointer] = arr[pointer], arr[i]
    return arr


arr = [int(x) for x in input().split()]
print(selection_sort(arr))
