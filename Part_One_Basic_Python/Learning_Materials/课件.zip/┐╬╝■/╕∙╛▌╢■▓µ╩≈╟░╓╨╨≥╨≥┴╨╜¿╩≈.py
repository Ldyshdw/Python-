# 根据二叉树前中序序列建树

class TreeNode:
    def __init__(self, x):
        self.value = x
        self.left = None
        self.right = None


def build_tree(preorder, inorder):
    if not preorder or not inorder:
        return []
    root_value = preorder.pop(0)
    root = TreeNode(root_value)
    root_index = inorder.index(root_value)

    root.left = build_tree(preorder, inorder[:root_index])
    root.right = build_tree(preorder, inorder[root_index + 1:])

    return root


def postorder(root):
    result = []
    if root:
        result.extend(postorder(root.left))
        result.extend(postorder(root.right))
        result.append(root.value)
    return result


while True:
    try:
        preorder = list(input())
        inorder = list(input())
        print(''.join(postorder(build_tree(preorder, inorder))))
    except EOFError:
        break
