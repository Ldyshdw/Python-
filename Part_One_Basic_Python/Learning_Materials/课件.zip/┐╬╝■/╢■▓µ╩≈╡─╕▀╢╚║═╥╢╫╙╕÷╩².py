# 求二叉树的高度和叶子数目
class TreeNode:
    def __init__(self):
        self.left = None
        self.right = None


def find_height(node):
    if node is None:
        return -1
    left_height = find_height(node.left)
    right_height = find_height(node.right)

    return max(left_height, right_height) + 1


def find_count(node):
    if node is None:
        return 0
    if node.left is None and node.right is None:
        return 1
    return find_count(node.left) + find_count(node.right)


n = int(input())
nodes = [TreeNode() for _ in range(n)]
has_parent = [False] * n
for i in range(n):
    left_index, right_index = map(int, input().split())
    if left_index != -1:
        nodes[i].left = nodes[left_index]
        has_parent[left_index] = True
    if right_index != -1:
        nodes[i].right = nodes[right_index]
        has_parent[right_index] = False

root_index = has_parent.index(False)
root = nodes[root_index]
print(find_height(root),find_count(root))

