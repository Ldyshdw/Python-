# 合法出站序列
# 比较出站序列的思路：看出站序列的头一个是否对应origin中头一个，若是，两个都pop(0)，若不是则，将origin中的头放在stack中储存，然后新元素先看stack中栈顶元素是不是
def is_valid(origin, output):
    lst_origin = list(origin)
    lst_output = list(output)
    if len(lst_origin) != len(lst_output):
        return False
    stack = []
    while lst_output:
        if stack:
            a = stack[-1]
            if lst_output[0] == str(a):
                stack.pop()
                lst_output.pop(0)
            else:
                if lst_origin:
                    stack.append(lst_origin.pop(0))
                else:
                    return False

        else:
            stack.append(lst_origin.pop(0))
    if stack:
        return False
    return True


origin = input().strip()
while True:
    try:
        output = input().strip()
        if is_valid(origin, output):
            print("YES")
        else:
            print("NO")
    except EOFError:
        break
